import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mem-chat',
  templateUrl: './mem-chat.page.html',
  styleUrls: ['./mem-chat.page.scss'],
})
export class MemChatPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
