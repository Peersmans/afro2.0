import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MemChatPage } from './mem-chat.page';

const routes: Routes = [
  {
    path: '',
    component: MemChatPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MemChatPageRoutingModule {}
