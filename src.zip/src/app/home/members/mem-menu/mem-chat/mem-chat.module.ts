import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MemChatPageRoutingModule } from './mem-chat-routing.module';

import { MemChatPage } from './mem-chat.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MemChatPageRoutingModule
  ],
  declarations: [MemChatPage]
})
export class MemChatPageModule {}
