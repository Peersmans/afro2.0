import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemMenuPage } from './mem-menu.page';

describe('MemMenuPage', () => {
  let component: MemMenuPage;
  let fixture: ComponentFixture<MemMenuPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MemMenuPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
