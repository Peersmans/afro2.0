import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-mem-doc',
  templateUrl: './mem-doc.page.html',
  styleUrls: ['./mem-doc.page.scss'],
})
export class MemDocPage implements OnInit {


  onFileSelected(event: any) {
    // Handle file selection logic here
    const file: File = event.target.files[0];
    if (file) {
      // Do something with the selected file
      console.log('Selected file:', file);
    }
  }
  constructor() { }

  ngOnInit() {
  }

}
