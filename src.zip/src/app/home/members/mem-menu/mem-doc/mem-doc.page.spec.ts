import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemDocPage } from './mem-doc.page';

describe('MemDocPage', () => {
  let component: MemDocPage;
  let fixture: ComponentFixture<MemDocPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MemDocPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
