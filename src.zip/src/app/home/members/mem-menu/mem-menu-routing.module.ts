import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MemMenuPage } from './mem-menu.page';

const routes: Routes = [
  {
    path: '',
    component: MemMenuPage
  },
  {
    path: 'mem-doc',
    loadChildren: () => import('./mem-doc/mem-doc.module').then( m => m.MemDocPageModule)
  },
  {
    path: 'mem-veilig',
    loadChildren: () => import('./mem-veilig/mem-veilig.module').then( m => m.MemVeiligPageModule)
  },
  {
    path: 'mem-tele',
    loadChildren: () => import('./mem-tele/mem-tele.module').then( m => m.MemTelePageModule)
  },
  {
    path: 'mem-news',
    loadChildren: () => import('./mem-news/mem-news.module').then( m => m.MemNewsPageModule)
  },
  {
    path: 'mem-chat',
    loadChildren: () => import('./mem-chat/mem-chat.module').then( m => m.MemChatPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MemMenuPageRoutingModule {}
