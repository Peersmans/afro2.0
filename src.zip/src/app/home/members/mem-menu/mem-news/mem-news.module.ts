import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MemNewsPageRoutingModule } from './mem-news-routing.module';

import { MemNewsPage } from './mem-news.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MemNewsPageRoutingModule
  ],
  declarations: [MemNewsPage]
})
export class MemNewsPageModule {}
