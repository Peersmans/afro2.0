import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemNewsPage } from './mem-news.page';

describe('MemNewsPage', () => {
  let component: MemNewsPage;
  let fixture: ComponentFixture<MemNewsPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MemNewsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
