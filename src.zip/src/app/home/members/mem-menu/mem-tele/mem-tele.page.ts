import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mem-tele',
  templateUrl: './mem-tele.page.html',
  styleUrls: ['./mem-tele.page.scss'],
})
export class MemTelePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
