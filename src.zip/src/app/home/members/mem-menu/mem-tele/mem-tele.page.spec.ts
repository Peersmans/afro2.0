import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemTelePage } from './mem-tele.page';

describe('MemTelePage', () => {
  let component: MemTelePage;
  let fixture: ComponentFixture<MemTelePage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MemTelePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
