import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MemVeiligPageRoutingModule } from './mem-veilig-routing.module';

import { MemVeiligPage } from './mem-veilig.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MemVeiligPageRoutingModule
  ],
  declarations: [MemVeiligPage]
})
export class MemVeiligPageModule {}
