import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MemMenu2PageRoutingModule } from './mem-menu2-routing.module';

import { MemMenu2Page } from './mem-menu2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MemMenu2PageRoutingModule
  ],
  declarations: [MemMenu2Page]
})
export class MemMenu2PageModule {}
