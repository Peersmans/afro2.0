import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MembersPage } from './members.page';
import { MemMenuPage } from './mem-menu/mem-menu.page';

const routes: Routes = [
  {
    path: '',
    component: MembersPage
  },
  {
    path: 'mem-menu',
    children: [{
      path:'', 
    loadChildren: () => import('./mem-menu/mem-menu.module').then( m => m.MemMenuPageModule)
  }]
  },
  {
    path: 'mem-menu2',
    children: [{
      path:'', 
    loadChildren: () => import('./mem-menu2/mem-menu2.module').then( m => m.MemMenu2PageModule)
  }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MembersPageRoutingModule {}
