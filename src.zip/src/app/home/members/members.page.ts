import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { MemMenuPage } from './mem-menu/mem-menu.page';
import { MemMenu2Page } from './mem-menu2/mem-menu2.page';

@Component({
  selector: 'app-members',
  templateUrl: './members.page.html',
  styleUrls: ['./members.page.scss'],
})
export class MembersPage  {

//  color: string = 'pink';
//  pincode: Array<number> = [];
//  pincodeLenght: number;
// event: any;
//  constructor(public navCtrl: NavController) {
  //  this.pincodeLenght = 0;
 // }

//  set(event: any) {
//    if (this.pincodeLenght < 4) {
//      this.pincodeLenght++;
//      this.pincode.push(event.srcElement.innerText)
   //   console.log(this.pincode, this.pincodeLenght);
//   window.location.href="../mem-menu/mem-menu.page.html";
//    }
//  }

//  cancel(event: any) {

//    this.pincodeLenght = 0;
//    this.pincode = [2580];

pincode: number[] = [];
pincodeLength: number = 0;

constructor(public navCtrl: NavController) {}

set(event: any) {
  if (this.pincodeLength < 4) {
    this.pincodeLength++;
    this.pincode.push(+event.srcElement.innerText); // Convert to number
  }

  if (this.pincodeLength === 4) {
    const correctPin1593 = [1, 5, 9, 3];
    const correctPin2500 = [2, 5, 0, 0];
    
    const isCorrectPin1593 = this.pincode.every((digit, index) => digit === correctPin1593[index]);
    const isCorrectPin2500 = this.pincode.every((digit, index) => digit === correctPin2500[index]);

    if (isCorrectPin1593) {
      console.log('navigating to mem-menu.page.html');
      this.navCtrl.navigateForward('../mem-menu/mem-menu');//krijg steeds foutmelding in console cannot match any route
    } else if (isCorrectPin2500) {
      console.log('navigating to mem-menu2.page.html');
      this.navCtrl.navigateForward('./mem-menu2');//idem hier
    } else {
      this.resetPin();
      console.log('Incorrect pin code. Please try again.');
    }
  }
}

resetPin() {
  this.pincode = [];
  this.pincodeLength = 0;
}
}
