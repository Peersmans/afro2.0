import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InfoPage } from './info.page';

const routes: Routes = [
  {
    path: '',
    component: InfoPage
  },
  {
    path: 'kamperen',
    loadChildren: () => import('./kamperen/kamperen.module').then( m => m.KamperenPageModule)
  },
  {
    path: 'homerule',
    loadChildren: () => import('./homerule/homerule.module').then( m => m.HomerulePageModule)
  },
  {
    path: 'randani',
    loadChildren: () => import('./randani/randani.module').then( m => m.RandaniPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InfoPageRoutingModule {}
