import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HomerulePageRoutingModule } from './homerule-routing.module';

import { HomerulePage } from './homerule.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HomerulePageRoutingModule
  ],
  declarations: [HomerulePage]
})
export class HomerulePageModule {}
