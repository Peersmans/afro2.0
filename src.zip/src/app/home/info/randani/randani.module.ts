import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RandaniPageRoutingModule } from './randani-routing.module';

import { RandaniPage } from './randani.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RandaniPageRoutingModule
  ],
  declarations: [RandaniPage]
})
export class RandaniPageModule {}
