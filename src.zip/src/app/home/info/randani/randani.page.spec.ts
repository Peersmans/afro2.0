import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RandaniPage } from './randani.page';

describe('RandaniPage', () => {
  let component: RandaniPage;
  let fixture: ComponentFixture<RandaniPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(RandaniPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
