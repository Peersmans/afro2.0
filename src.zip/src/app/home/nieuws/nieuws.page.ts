import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nieuws',
  templateUrl: './nieuws.page.html',
  styleUrls: ['./nieuws.page.scss'],
})
export class NieuwsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
