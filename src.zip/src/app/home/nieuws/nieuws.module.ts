import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NieuwsPageRoutingModule } from './nieuws-routing.module';

import { NieuwsPage } from './nieuws.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NieuwsPageRoutingModule
  ],
  declarations: [NieuwsPage]
})
export class NieuwsPageModule {}
